
import 'package:flutter/material.dart';

void main() {
  runApp(RoletaBotApp());
}

class RoletaBotApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bot Roleta Europeia',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: RoletaHomePage(),
    );
  }
}

class RoletaHomePage extends StatefulWidget {
  @override
  _RoletaHomePageState createState() => _RoletaHomePageState();
}

class _RoletaHomePageState extends State<RoletaHomePage> {
  final TextEditingController _controller = TextEditingController();
  String _resultado = '';
  List<String> _historico = [];

  void _analisarResultados() {
    final input = _controller.text.toUpperCase().replaceAll(' ', '');
    final resultados = input.split(',').where((c) => c == 'V' || c == 'P' || c == '0').toList();

    if (resultados.isEmpty) {
      setState(() {
        _resultado = 'Insira resultados válidos: V, P ou 0.';
      });
      return;
    }

    Map<String, int> contagem = {'V': 0, 'P': 0, '0': 0};
    for (var cor in resultados) {
      contagem[cor] = contagem[cor]! + 1;
    }

    String ultima = resultados.last;
    int sequencia = 1;
    for (int i = resultados.length - 2; i >= 0; i--) {
      if (resultados[i] == ultima) {
        sequencia++;
      } else {
        break;
      }
    }

    String sugestao = '';
    String proxima = '';

    if (contagem['0']! > 0 && ultima != '0') {
      sugestao += 'Aviso: Zero apareceu recentemente. Fique atento.\n';
    }

    if (sequencia >= 3 && ultima != '0') {
      String oposta = ultima == 'P' ? 'V' : 'P';
      sugestao += 'Sequência de $ultima detectada. Sugestão: Apostar em $oposta.\n';
      proxima = oposta;
    } else {
      proxima = contagem['V']! < contagem['P']! ? 'V' : 'P';
      sugestao += 'Sugestão com base na frequência: Apostar em $proxima.\n';
    }

    String corProxima = proxima == 'V' ? 'VERMELHO' : 'PRETO';

    setState(() {
      _resultado = 'Cor mais provável: $corProxima\n$sugestao';
      _historico.add(_resultado);
    });
  }

  void _limpar() {
    setState(() {
      _controller.clear();
      _resultado = '';
      _historico.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bot Roleta Europeia'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Digite os últimos resultados (ex: V,P,V,0)',
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _analisarResultados,
              child: Text('Analisar'),
            ),
            ElevatedButton(
              onPressed: _limpar,
              child: Text('Limpar'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
            ),
            SizedBox(height: 16),
            Text(
              _resultado,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 16),
            if (_historico.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: _historico.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(_historico[index]),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
